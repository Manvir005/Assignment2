var builder = DistributedApplication.CreateBuilder(args);

var apiService = builder.AddProject<Projects.mauiApp1_ApiService>("apiservice");

builder.AddProject<Projects.mauiApp1_Web>("webfrontend")
    .WithExternalHttpEndpoints()
    .WithReference(apiService)
    .WaitFor(apiService);

builder.Build().Run();
